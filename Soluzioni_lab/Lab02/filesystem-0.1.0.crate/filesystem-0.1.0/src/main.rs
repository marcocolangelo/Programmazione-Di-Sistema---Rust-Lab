use filesystem::{Dir, File, FileType, Filesystem, Node};


fn main() {
    //let mut myfs = Filesystem::new();

    // myfs.mk_dir("/home/").unwrap();
    
}
